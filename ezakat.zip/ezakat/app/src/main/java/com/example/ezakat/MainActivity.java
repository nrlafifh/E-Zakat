package com.example.ezakat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final DecimalFormat df = new DecimalFormat("0.00");

    EditText etWeight, etValue;
    RadioButton rbSelect;
    RadioGroup rgType;
    TextView tvTotValue, tvZakat, tvCalc, tvTotZakat;
    Button btnCalc;

    double gold=0;

    public boolean onCreateOptionsMenu (Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()){
            case R.id.about:
                //Toast.makeText(this,"This is about ezakat application.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);
                break;

            case R.id.ezakat:
                //Toast.makeText(this,"This is about ezakat application.", Toast.LENGTH_LONG).show();
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etWeight = (EditText) findViewById(R.id.goldWeight);
        etValue = (EditText) findViewById(R.id.goldValue);
        rgType = (RadioGroup) findViewById(R.id.goldType);
        btnCalc = (Button) findViewById(R.id.btnCalc);
        tvTotValue = (TextView) findViewById(R.id.totValue);
        tvZakat = (TextView) findViewById(R.id.payable);
        tvCalc = (TextView) findViewById(R.id.calc);
        tvTotZakat = (TextView) findViewById(R.id.totZakat);

        btnCalc.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int radioId = rgType.getCheckedRadioButtonId();

        rbSelect = findViewById(radioId);

        if (rbSelect.getText().equals("Keep")) {
            gold = 85;
        } else if (rbSelect.getText().equals("Wear")) {
            gold = 200;
        }

        try{
            switch (view.getId()){
                case R.id.btnCalc:
                    double weight = Double.parseDouble(etWeight.getText().toString());
                    double value = Double.parseDouble(etValue.getText().toString());

                    double totalValue = weight * value;
                    double zakat = (weight - gold) * value;

                    if(zakat < 0){
                        zakat = 0;
                    }
                    double totalZakat = zakat * 0.025;

                    tvTotValue.setText(totalValue + "");
                    tvZakat.setText(zakat + "");
                    tvCalc.setText("(" + weight + "-" + gold + ") X " + value);
                    tvTotZakat.setText(totalZakat + "");
                break;
            }
        }catch(java.lang.NumberFormatException nfe){
            Toast.makeText(this,"Please enter a valid number", Toast.LENGTH_SHORT).show();
        } catch (Exception exp){
            Toast.makeText(this, "Unknown Exception" + exp.getMessage(), Toast.LENGTH_SHORT).show();

            Log.d("Exception", exp.getMessage());
        }
    }
}